package com.example.recipebook

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class vegActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_veg)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
    fun onvegStarters(v: View){
        val vegstarters_Intent = Intent(this,vegstartersActivity::class.java)
        startActivity(vegstarters_Intent)
    }
    fun onvegTiffins(v: View){
        val tiffins_Intent = Intent(this, vegtiffinsActivity::class.java)
        startActivity(tiffins_Intent)
    }
    fun onVegmaincourse(v: View){
        val maincourse_Intent = Intent(this, vegmaincourseActivity::class.java)
        startActivity(maincourse_Intent)
    }
    fun onVegdessert(v: View){
        val dessert_Intent = Intent(this, vegdessertActivity::class.java)
        startActivity(dessert_Intent)
    }
}