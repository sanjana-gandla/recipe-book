package com.example.recipebook

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class cornsoupActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_cornsoup)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
    fun opencsIngredients(v: View){
        val csing_Intent = Intent(this, csingActivity::class.java)
        startActivity(csing_Intent)
    }
    fun opencsnut(v: View){
        val csnut_Intent = Intent(this, csnutActivity::class.java)
        startActivity(csnut_Intent)
    }
    fun oncspro(v: View){
        val cspro_Intent = Intent(this, csproActivity::class.java)
        startActivity(cspro_Intent)
    }
    fun oncsvideo(v: View){
        val csvideo_Intent = Intent(this, csvideoActivity::class.java)
        startActivity(csvideo_Intent)
    }
}