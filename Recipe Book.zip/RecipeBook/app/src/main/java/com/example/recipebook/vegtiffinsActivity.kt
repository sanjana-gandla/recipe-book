package com.example.recipebook

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class vegtiffinsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_vegtiffins)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
    fun onMasala(v: View){
        val masala_Intent = Intent(this, masalaActivity::class.java)
        startActivity(masala_Intent)
    }
    fun onDahi(v: View){
        val dahi_Intent = Intent(this, dahiActivity::class.java)
        startActivity(dahi_Intent)
    }
    fun onOnion(v: View){
        val onion_Intent = Intent(this, onionActivity::class.java)
        startActivity(onion_Intent)
    }
    fun onIdli(v: View){
        val idli_Intent = Intent(this, idliActivity::class.java)
        startActivity(idli_Intent)
    }
    fun onMysore(v: View){
        val mysore_Intent = Intent(this, mysoreActivity::class.java)
        startActivity(mysore_Intent)
    }
    fun onUpma(v: View){
        val upma_Intent = Intent(this, upmaActivity::class.java)
        startActivity(upma_Intent)
    }
    fun onKaju(v: View){
        val kaju_Intent = Intent(this, kajuActivity::class.java)
        startActivity(kaju_Intent)
    }
}